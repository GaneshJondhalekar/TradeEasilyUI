from django.shortcuts import render

# Create your views here.
def Home(request):
    return render(request,'home.html')

def PCR_Live(request):
    return render(request,'Live_PCR.html')